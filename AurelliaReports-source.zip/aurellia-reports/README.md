# Aurellia Reports

A calm, pastel pink and white menstrual cycle and cash-flow journal for Android.

Aurellia Reports is a **standalone, local-only** app. It has no internet permission and no access to SMS, contacts, location, camera, microphone, or files. Everything you log stays in the app's private storage on the device.

> This is a new, clean project. It is **not** a modification of the BABARPHANTOM APK and does not contain its surveillance or remote-control components.

## What the app does

- **Today (the index):** cycle day, current phase, next-period prediction, quick start/end actions, recent periods, and a privacy reminder.
- **Calendar:** month view with period days highlighted. Tap a day to start a period, end an ongoing period, edit details, or delete an entry.
- **History:** every logged period with duration, flow, mood, symptoms, and notes. Delete with confirmation.
- **Money:** income and expense records by month, with a running net balance, a six-month cash-flow bar chart, and an expenses-by-category breakdown. Records are editable and deletable. Amounts use your device currency and are stored locally as minor units.
- **Settings:** average cycle length (21–40 days) and period length (2–10 days), privacy information, and reset.
- **Logging:** flow, mood, symptoms, notes, and optional end date.
- **Prediction:** average cycle length from your last up to six gaps; otherwise uses the value in Settings.
- **No accounts, no cloud, no analytics, no network code.**

## Build it

No APK is checked into this folder; build it from source with one of the options below.

### Android Studio

1. Install **Android Studio** with **JDK 17** and **Android SDK 35**.
2. Open the `aurellia-reports` folder.
3. Let Gradle sync.
4. Press **Run**.

### Command line

```bash
cd aurellia-reports
./gradlew testDebugUnitTest assembleDebug
```

The debug APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

### GitHub Actions

Pushing the project to GitHub runs `.github/workflows/build.yml`, which runs the unit tests, builds a debug APK, and uploads it as a workflow artifact. You can also run it manually from the **Actions** tab.

### On an Android phone

Android Studio does not run on Android, so use one of these instead:

1. **Cloud build (recommended):** push the project to GitHub from a phone Git client or Termux, run the **Build Aurellia Reports** workflow from the Actions tab, then download the `aurellia-reports-debug` artifact. Unzip it to get `app-debug.apk`.
2. **On-device Gradle IDE:** install AndroidIDE/AIDE+ or another Android-native Gradle IDE that provides JDK 17, Android SDK 35, and an Android-compatible `aapt2`. Open the `aurellia-reports` folder, install the SDK/build tools when prompted, and run:

```bash
./gradlew :app:assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. On-device builds need several GB of free storage and can be slow on the first dependency download.

Termux alone is not enough: the normal Android SDK build-tools are not built for Android/ARM, and Gradle's Android plugin needs a compatible on-device toolchain.

## Identity

| | |
|---|---|
| App name | Aurellia Reports |
| Package / applicationId | `com.aurellia.reports` |
| Namespace | `com.aurellia.reports` |
| Min SDK | 26 |
| Target / compile SDK | 35 |
| Version | 1.0.0 (1) |
| Language / UI | Kotlin + Jetpack Compose Material 3 |

## Project map

```text
app/src/main/java/com/aurellia/reports/
├── MainActivity.kt                 # edge-to-edge host
├── data/
│   ├── Models.kt                   # PeriodEntry, Flow, Mood, settings, status
│   ├── CycleCalculator.kt          # phase, cycle day, average, next period
│   ├── MoneyModels.kt              # MoneyEntry, categories, money formatting
│   ├── MoneyCalculator.kt          # monthly totals, cash flow, category totals
│   ├── AurelliaStore.kt            # local SharedPreferences + JSON storage
│   └── DateFormats.kt
└── ui/
    ├── AurelliaApp.kt              # scaffold + bottom navigation
    ├── theme/                      # pastel rose/white color, type, shapes
    ├── components/                 # entry card, editors, date picker, charts
    └── screens/
        ├── TodayScreen.kt          # the index / dashboard
        ├── CalendarScreen.kt
        ├── HistoryScreen.kt
        ├── MoneyScreen.kt          # income/expense records and cash flow
        └── SettingsScreen.kt
```

## Privacy

The manifest deliberately declares **no permissions**. That means the app cannot access the network, messages, contacts, location, camera, microphone, or shared storage. Cycle and money data is stored with `SharedPreferences` in the app's private directory. Uninstalling the app removes it.

## Extending it yourself

See [docs/ADDING_FEATURES.md](docs/ADDING_FEATURES.md) for a step-by-step guide to:

- adding a new field to a period or money record,
- adding a new screen/tab or extending the Money tab,
- adding local reminders/notifications,
- exporting and importing data,
- adding tests,
- signing a release build.

The guide is written for **this standalone project**. Do not merge this UI or code into the BABARPHANTOM build or any app that keeps covert data collection.

## Disclaimer

Aurellia Reports is a personal record, not medical advice, contraception, or financial advice. Predictions are estimates and can shift with stress, illness, travel, and other factors. If something feels unusual, talk to a healthcare professional.
