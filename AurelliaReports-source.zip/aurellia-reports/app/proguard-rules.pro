# Add project specific ProGuard rules here.
# This project ships without minification enabled by default.
