package com.aurellia.reports.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

/**
 * Small, dependency-free local store. Data lives in this app's private
 * SharedPreferences file and is never uploaded anywhere.
 */
class AurelliaStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("aurellia_reports", Context.MODE_PRIVATE)

    fun loadEntries(): List<PeriodEntry> {
        val raw = prefs.getString(KEY_ENTRIES, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    jsonToEntry(item)?.let { entry -> add(entry) }
                }
            }
        }.getOrDefault(emptyList())
    }

    fun loadSettings(): AppSettings = AppSettings(
        cycleLength = prefs.getInt(KEY_CYCLE_LENGTH, 28).coerceIn(21, 40),
        periodLength = prefs.getInt(KEY_PERIOD_LENGTH, 5).coerceIn(2, 10)
    )

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putInt(KEY_CYCLE_LENGTH, settings.cycleLength.coerceIn(21, 40))
            .putInt(KEY_PERIOD_LENGTH, settings.periodLength.coerceIn(2, 10))
            .apply()
    }

    fun upsert(entry: PeriodEntry) {
        val entries = loadEntries().toMutableList()
        val nextStart = entries
            .filter { it.id != entry.id && it.start.isAfter(entry.start) }
            .minByOrNull { it.start.toEpochDay() }
            ?.start
        val currentEnd = entry.end
        val rawEnd = when {
            nextStart == null -> currentEnd
            currentEnd == null -> nextStart.minusDays(1)
            currentEnd != null && currentEnd.isAfter(nextStart.minusDays(1)) -> nextStart.minusDays(1)
            else -> currentEnd
        }
        val safeEnd = if (rawEnd != null && rawEnd.isBefore(entry.start)) entry.start else rawEnd
        val safeEntry = entry.copy(end = safeEnd)
        val index = entries.indexOfFirst { it.id == entry.id }
        if (index >= 0) entries[index] = safeEntry else entries.add(safeEntry)
        saveEntries(entries)
    }

    fun startPeriod(date: LocalDate): PeriodEntry {
        val today = LocalDate.now()
        val entries = loadEntries().toMutableList()
        val covering = entries.firstOrNull { it.covers(date, today) }
        if (covering != null) {
            if (covering.end == null || !date.isEqual(covering.end) || date.isEqual(covering.start)) {
                return covering
            }
            // The previous period ended today. Trim it by one day so a new
            // period can begin today without overlapping it.
            val index = entries.indexOf(covering)
            entries[index] = covering.copy(end = date.minusDays(1))
        }

        // If a previous period is still open, close it the day before this one.
        val active = entries
            .filter { it.end == null && !date.isBefore(it.start) }
            .maxByOrNull { it.start.toEpochDay() }
        if (active != null) {
            val closeAt = date.minusDays(1)
            if (!closeAt.isBefore(active.start)) {
                val index = entries.indexOf(active)
                entries[index] = active.copy(end = closeAt)
            }
        }

        // If this is a backfilled period, stop it before the next logged entry.
        val nextStart = entries
            .filter { it.start.isAfter(date) }
            .minByOrNull { it.start.toEpochDay() }
            ?.start
        val end = nextStart?.minusDays(1)?.takeIf { !it.isBefore(date) }
        val entry = PeriodEntry(id = System.currentTimeMillis(), start = date, end = end)
        entries.add(entry)
        saveEntries(entries)
        return entry
    }

    fun endPeriod(date: LocalDate) {
        val entries = loadEntries().toMutableList()
        val active = entries
            .filter { it.end == null && !date.isBefore(it.start) }
            .maxByOrNull { it.start.toEpochDay() } ?: return
        val nextStart = entries
            .filter { it.id != active.id && it.start.isAfter(active.start) }
            .minByOrNull { it.start.toEpochDay() }
            ?.start
        val end = if (nextStart != null && !nextStart.isAfter(date)) {
            nextStart.minusDays(1)
        } else {
            date
        }
        val index = entries.indexOf(active)
        if (index >= 0) {
            val safeEnd = if (end.isBefore(active.start)) active.start else end
            entries[index] = active.copy(end = safeEnd)
            saveEntries(entries)
        }
    }

    fun deleteEntry(id: Long) {
        saveEntries(loadEntries().filterNot { it.id == id })
    }

    fun loadMoneyEntries(): List<MoneyEntry> {
        val raw = prefs.getString(KEY_MONEY_ENTRIES, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    jsonToMoneyEntry(item)?.let { entry -> add(entry) }
                }
            }
        }.getOrDefault(emptyList())
    }

    fun upsertMoney(entry: MoneyEntry) {
        if (entry.amountMinor <= 0L) return
        val safeEntry = entry.copy(
            category = entry.category.ifBlank { "Other" },
            note = entry.note.trim()
        )
        val entries = loadMoneyEntries().toMutableList()
        val index = entries.indexOfFirst { it.id == safeEntry.id }
        if (index >= 0) entries[index] = safeEntry else entries.add(safeEntry)
        saveMoneyEntries(entries)
    }

    fun deleteMoneyEntry(id: Long) {
        saveMoneyEntries(loadMoneyEntries().filterNot { it.id == id })
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    private fun saveEntries(entries: List<PeriodEntry>) {
        val array = JSONArray()
        entries.sortedBy { it.start.toEpochDay() }.forEach { array.put(entryToJson(it)) }
        prefs.edit().putString(KEY_ENTRIES, array.toString()).apply()
    }

    private fun entryToJson(entry: PeriodEntry): JSONObject = JSONObject().apply {
        put("id", entry.id)
        put("start", entry.start.toString())
        entry.end?.let { put("end", it.toString()) }
        put("flow", entry.flow.name)
        entry.mood?.let { put("mood", it.name) }
        put("notes", entry.notes)
        put("symptoms", JSONArray(entry.symptoms.toList()))
    }

    private fun jsonToEntry(json: JSONObject): PeriodEntry? = runCatching {
        val start = LocalDate.parse(json.getString("start"))
        val end = json.optString("end")
            .takeIf { it.isNotBlank() && it != "null" }
            ?.let(LocalDate::parse)
        val flow = runCatching { Flow.valueOf(json.optString("flow", Flow.MEDIUM.name)) }
            .getOrDefault(Flow.MEDIUM)
        val mood = json.optString("mood")
            .takeIf { it.isNotBlank() && it != "null" }
            ?.let { name -> runCatching { Mood.valueOf(name) }.getOrNull() }
        val symptoms = mutableSetOf<String>()
        json.optJSONArray("symptoms")?.let { array ->
            for (i in 0 until array.length()) {
                val symptom = array.optString(i)
                if (symptom.isNotBlank()) symptoms.add(symptom)
            }
        }
        PeriodEntry(
            id = json.getLong("id"),
            start = start,
            end = end,
            flow = flow,
            symptoms = symptoms,
            mood = mood,
            notes = json.optString("notes")
        )
    }.getOrNull()

    private fun saveMoneyEntries(entries: List<MoneyEntry>) {
        val array = JSONArray()
        entries
            .sortedWith(compareBy<MoneyEntry> { it.date.toEpochDay() }.thenBy { it.id })
            .forEach { array.put(moneyToJson(it)) }
        prefs.edit().putString(KEY_MONEY_ENTRIES, array.toString()).apply()
    }

    private fun moneyToJson(entry: MoneyEntry): JSONObject = JSONObject().apply {
        put("id", entry.id)
        put("date", entry.date.toString())
        put("type", entry.type.name)
        put("amountMinor", entry.amountMinor)
        put("category", entry.category)
        put("note", entry.note)
    }

    private fun jsonToMoneyEntry(json: JSONObject): MoneyEntry? = runCatching {
        val amount = json.getLong("amountMinor")
        require(amount > 0L)
        val type = runCatching {
            MoneyType.valueOf(json.optString("type", MoneyType.EXPENSE.name))
        }.getOrDefault(MoneyType.EXPENSE)
        MoneyEntry(
            id = json.getLong("id"),
            date = LocalDate.parse(json.getString("date")),
            type = type,
            amountMinor = amount,
            category = json.optString("category")
                .takeIf { it.isNotBlank() && it != "null" }
                ?: "Other",
            note = json.optString("note")
                .takeIf { it.isNotBlank() && it != "null" }
                .orEmpty()
        )
    }.getOrNull()

    private companion object {
        const val KEY_ENTRIES = "entries"
        const val KEY_MONEY_ENTRIES = "money_entries"
        const val KEY_CYCLE_LENGTH = "cycle_length"
        const val KEY_PERIOD_LENGTH = "period_length"
    }
}
