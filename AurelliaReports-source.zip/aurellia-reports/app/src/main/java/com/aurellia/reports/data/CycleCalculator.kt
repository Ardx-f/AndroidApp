package com.aurellia.reports.data

import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.math.abs
import kotlin.math.roundToInt

object CycleCalculator {

    fun averageCycle(entries: List<PeriodEntry>, fallback: Int): Int {
        val starts = entries.map { it.start }.distinct().sortedBy { it.toEpochDay() }
        val gaps = starts.zipWithNext { a, b -> ChronoUnit.DAYS.between(a, b).toInt() }
            .filter { it in 15..60 }
            .takeLast(6)
        if (gaps.isEmpty()) return fallback
        return gaps.average().roundToInt().coerceIn(15, 60)
    }

    fun calculate(
        entries: List<PeriodEntry>,
        settings: AppSettings,
        today: LocalDate
    ): CycleStatus {
        val sorted = entries.sortedBy { it.start.toEpochDay() }
        val last = sorted.lastOrNull()
        val active = sorted.lastOrNull { it.end == null && !today.isBefore(it.start) }
        val average = averageCycle(sorted, settings.cycleLength)

        if (last == null || today.isBefore(last.start)) {
            return CycleStatus(
                activeEntry = active,
                lastEntry = last,
                averageCycle = average,
                cycleDay = null,
                phase = CyclePhase.NONE,
                nextPeriod = null,
                daysUntilNext = null,
                isLate = false
            )
        }

        val day = (ChronoUnit.DAYS.between(last.start, today).toInt() + 1).coerceAtLeast(1)
        val next = last.start.plusDays(average.toLong())
        val until = ChronoUnit.DAYS.between(today, next)

        val phase = when {
            active != null -> CyclePhase.MENSTRUAL
            day <= settings.periodLength -> CyclePhase.MENSTRUAL
            day > average -> CyclePhase.LUTEAL
            abs(day - average / 2) <= 1 -> CyclePhase.OVULATION
            day < average / 2 -> CyclePhase.FOLLICULAR
            else -> CyclePhase.LUTEAL
        }

        return CycleStatus(
            activeEntry = active,
            lastEntry = last,
            averageCycle = average,
            cycleDay = day,
            phase = phase,
            nextPeriod = next,
            daysUntilNext = until,
            isLate = active == null && until < 0
        )
    }
}
