package com.aurellia.reports.data

import java.time.format.DateTimeFormatter

val ShortDate: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d")
val LongDate: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM d, yyyy")
val MonthYear: DateTimeFormatter = DateTimeFormatter.ofPattern("MMMM yyyy")
val ShortMonth: DateTimeFormatter = DateTimeFormatter.ofPattern("MMM")
val FullDayDate: DateTimeFormatter = DateTimeFormatter.ofPattern("EEEE, MMMM d")
