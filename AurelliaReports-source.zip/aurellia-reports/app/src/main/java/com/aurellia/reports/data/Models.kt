package com.aurellia.reports.data

import java.time.LocalDate
import java.time.format.DateTimeFormatter

enum class Flow(val label: String) {
    SPOTTING("Spotting"),
    LIGHT("Light"),
    MEDIUM("Medium"),
    HEAVY("Heavy")
}

enum class Mood(val label: String, val symbol: String) {
    CALM("Calm", "🌿"),
    HAPPY("Happy", "☀️"),
    ENERGETIC("Energetic", "✨"),
    TIRED("Tired", "🌙"),
    SENSITIVE("Sensitive", "💗"),
    CRAMPY("Crampy", "🫧")
}

/**
 * One logged period. A period may still be ongoing (end == null).
 * All dates are local dates; nothing is sent off the device.
 */
data class PeriodEntry(
    val id: Long,
    val start: LocalDate,
    val end: LocalDate? = null,
    val flow: Flow = Flow.MEDIUM,
    val symptoms: Set<String> = emptySet(),
    val mood: Mood? = null,
    val notes: String = ""
) {
    fun covers(date: LocalDate, today: LocalDate = LocalDate.now()): Boolean {
        if (date.isBefore(start)) return false
        val effectiveEnd = end ?: today
        return !date.isAfter(effectiveEnd)
    }

    val durationDays: Int
        get() = (((end ?: LocalDate.now()).toEpochDay() - start.toEpochDay()).toInt() + 1).coerceAtLeast(1)

    val rangeLabel: String
        get() {
            val first = start.format(DateTimeFormatter.ofPattern("MMM d"))
            val last = end
            return if (last == null) {
                "$first – ongoing"
            } else {
                "$first – ${last.format(DateTimeFormatter.ofPattern("MMM d"))}"
            }
        }
}

data class AppSettings(
    val cycleLength: Int = 28,
    val periodLength: Int = 5
)

enum class CyclePhase(val label: String) {
    NONE("No data yet"),
    MENSTRUAL("Menstrual"),
    FOLLICULAR("Follicular"),
    OVULATION("Ovulation"),
    LUTEAL("Luteal")
}

data class CycleStatus(
    val activeEntry: PeriodEntry?,
    val lastEntry: PeriodEntry?,
    val averageCycle: Int,
    val cycleDay: Int?,
    val phase: CyclePhase,
    val nextPeriod: LocalDate?,
    val daysUntilNext: Long?,
    val isLate: Boolean
)
