package com.aurellia.reports.data

import java.time.YearMonth

object MoneyCalculator {

    fun summary(entries: List<MoneyEntry>, month: YearMonth): MoneySummary {
        var income = 0L
        var expense = 0L
        entries.forEach { entry ->
            if (YearMonth.from(entry.date) != month) return@forEach
            when (entry.type) {
                MoneyType.INCOME -> income += entry.amountMinor
                MoneyType.EXPENSE -> expense += entry.amountMinor
            }
        }
        return MoneySummary(incomeMinor = income, expenseMinor = expense)
    }

    fun entriesForMonth(entries: List<MoneyEntry>, month: YearMonth): List<MoneyEntry> =
        entries
            .filter { YearMonth.from(it.date) == month }
            .sortedWith(
                compareByDescending<MoneyEntry> { it.date.toEpochDay() }
                    .thenByDescending { it.id }
            )

    /**
     * Oldest month first, so it can be rendered directly left-to-right in a
     * cash-flow chart.
     */
    fun monthly(
        entries: List<MoneyEntry>,
        endMonth: YearMonth,
        count: Int = 6
    ): List<MonthlyCashFlow> {
        require(count > 0) { "count must be positive" }
        return (count - 1 downTo 0).map { offset ->
            val month = endMonth.minusMonths(offset.toLong())
            val totals = summary(entries, month)
            MonthlyCashFlow(
                month = month,
                incomeMinor = totals.incomeMinor,
                expenseMinor = totals.expenseMinor
            )
        }
    }

    fun expensesByCategory(
        entries: List<MoneyEntry>,
        month: YearMonth
    ): List<Pair<String, Long>> =
        entries
            .asSequence()
            .filter {
                it.type == MoneyType.EXPENSE && YearMonth.from(it.date) == month
            }
            .groupBy { it.category }
            .map { (category, rows) -> category to rows.sumOf { it.amountMinor } }
            .sortedByDescending { it.second }
}
