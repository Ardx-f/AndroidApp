package com.aurellia.reports.data

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth

enum class MoneyType(val label: String) {
    INCOME("Income"),
    EXPENSE("Expense")
}

/**
 * Simple category suggestions. Categories are stored as plain strings so a
 * future version can add custom categories without a schema migration.
 */
object MoneyCategories {
    val income = listOf("Salary", "Business", "Freelance", "Gifts", "Other income")
    val expense = listOf(
        "Food",
        "Rent",
        "Transport",
        "Bills",
        "Health",
        "Shopping",
        "Education",
        "Other expense"
    )

    fun forType(type: MoneyType): List<String> =
        if (type == MoneyType.INCOME) income else expense
}

/**
 * Money is stored in minor units (for example cents or paise) so adding and
 * subtracting values does not accumulate floating-point errors.
 */
data class MoneyEntry(
    val id: Long,
    val date: LocalDate,
    val type: MoneyType,
    val amountMinor: Long,
    val category: String,
    val note: String = ""
)

data class MoneySummary(
    val incomeMinor: Long = 0L,
    val expenseMinor: Long = 0L
) {
    val netMinor: Long get() = incomeMinor - expenseMinor
}

data class MonthlyCashFlow(
    val month: YearMonth,
    val incomeMinor: Long,
    val expenseMinor: Long
) {
    val netMinor: Long get() = incomeMinor - expenseMinor
}

object MoneyFormat {
    private val currencyFormat: NumberFormat = NumberFormat.getCurrencyInstance()

    fun format(minor: Long): String =
        currencyFormat.format(BigDecimal.valueOf(minor, 2))

    fun signed(entry: MoneyEntry): String {
        val sign = if (entry.type == MoneyType.INCOME) "+" else "−"
        return "$sign${format(entry.amountMinor)}"
    }

    /**
     * Accepts a plain decimal amount such as 1250, 1250.50, 1,250.50 or 12,50.
     * When both separators are present, the last one is treated as the decimal
     * separator. A lone comma followed by one or two digits is treated as a
     * decimal comma; otherwise commas are grouping separators.
     */
    fun parseToMinor(raw: String): Long? {
        val cleaned = normalizeAmount(raw)
        if (cleaned.isEmpty()) return null
        val value = cleaned.toBigDecimalOrNull() ?: return null
        if (value <= BigDecimal.ZERO) return null
        val minor = runCatching {
            value.movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        }.getOrNull() ?: return null
        return minor.takeIf { it > 0L }
    }

    fun toInput(minor: Long): String =
        BigDecimal.valueOf(minor, 2).stripTrailingZeros().toPlainString()

    private fun normalizeAmount(raw: String): String {
        val cleaned = raw
            .trim()
            .replace(" ", "")
            .replace("\u00A0", "")
        if (cleaned.isEmpty()) return cleaned

        val lastComma = cleaned.lastIndexOf(',')
        val lastDot = cleaned.lastIndexOf('.')
        return when {
            lastComma >= 0 && lastDot >= 0 -> {
                if (lastDot > lastComma) {
                    cleaned.replace(",", "")
                } else {
                    cleaned.replace(".", "").replace(',', '.')
                }
            }

            lastComma >= 0 -> {
                val digitsAfter = cleaned.length - lastComma - 1
                if (digitsAfter in 1..2) cleaned.replace(',', '.') else cleaned.replace(",", "")
            }

            else -> cleaned
        }
    }
}
