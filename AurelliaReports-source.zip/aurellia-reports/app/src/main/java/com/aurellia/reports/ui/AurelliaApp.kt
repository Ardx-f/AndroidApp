package com.aurellia.reports.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.AurelliaStore
import com.aurellia.reports.data.CycleCalculator
import com.aurellia.reports.data.MoneyEntry
import com.aurellia.reports.ui.screens.CalendarScreen
import com.aurellia.reports.ui.screens.HistoryScreen
import com.aurellia.reports.ui.screens.MoneyScreen
import com.aurellia.reports.ui.screens.SettingsScreen
import com.aurellia.reports.ui.screens.TodayScreen
import com.aurellia.reports.ui.theme.Blush
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.MutedInk
import kotlinx.coroutines.delay
import java.time.LocalDate

private data class AurelliaTab(
    val label: String,
    val icon: ImageVector
)

@Composable
fun AurelliaApp() {
    val context = LocalContext.current
    val store = remember { AurelliaStore(context.applicationContext) }

    var entries by remember { mutableStateOf(store.loadEntries()) }
    var moneyEntries by remember { mutableStateOf(store.loadMoneyEntries()) }
    var settings by remember { mutableStateOf(store.loadSettings()) }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var today by remember { mutableStateOf(LocalDate.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(60_000L)
            today = LocalDate.now()
        }
    }

    val status = remember(entries, settings, today) {
        CycleCalculator.calculate(entries, settings, today)
    }

    fun refresh() {
        entries = store.loadEntries()
        moneyEntries = store.loadMoneyEntries()
        settings = store.loadSettings()
    }

    val tabs = listOf(
        AurelliaTab("Today", Icons.Outlined.Home),
        AurelliaTab("Calendar", Icons.Outlined.CalendarMonth),
        AurelliaTab("History", Icons.Outlined.History),
        AurelliaTab("Money", Icons.Outlined.AccountBalanceWallet),
        AurelliaTab("Settings", Icons.Outlined.Settings)
    )

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 0.dp
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.label
                            )
                        },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepRose,
                            selectedTextColor = DeepRose,
                            indicatorColor = Blush,
                            unselectedIconColor = MutedInk,
                            unselectedTextColor = MutedInk
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> TodayScreen(
                    today = today,
                    entries = entries,
                    settings = settings,
                    status = status,
                    onStartPeriod = {
                        store.startPeriod(it)
                        refresh()
                    },
                    onEndPeriod = {
                        store.endPeriod(it)
                        refresh()
                    },
                    onSaveEntry = {
                        store.upsert(it)
                        refresh()
                    },
                    onOpenHistory = { selectedTab = 2 }
                )

                1 -> CalendarScreen(
                    today = today,
                    entries = entries,
                    onStartPeriod = {
                        store.startPeriod(it)
                        refresh()
                    },
                    onEndPeriod = {
                        store.endPeriod(it)
                        refresh()
                    },
                    onSaveEntry = {
                        store.upsert(it)
                        refresh()
                    },
                    onDeleteEntry = {
                        store.deleteEntry(it)
                        refresh()
                    }
                )

                2 -> HistoryScreen(
                    entries = entries,
                    status = status,
                    onSaveEntry = {
                        store.upsert(it)
                        refresh()
                    },
                    onDeleteEntry = {
                        store.deleteEntry(it)
                        refresh()
                    }
                )

                3 -> MoneyScreen(
                    entries = moneyEntries,
                    today = today,
                    onSave = {
                        store.upsertMoney(it)
                        refresh()
                    },
                    onDelete = {
                        store.deleteMoneyEntry(it)
                        refresh()
                    }
                )

                else -> SettingsScreen(
                    settings = settings,
                    onSettingsChange = {
                        store.saveSettings(it)
                        settings = it
                    },
                    onReset = {
                        store.clearAll()
                        refresh()
                    }
                )
            }
        }
    }
}
