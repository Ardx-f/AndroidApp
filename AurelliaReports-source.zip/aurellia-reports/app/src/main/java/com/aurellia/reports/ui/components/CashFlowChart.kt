package com.aurellia.reports.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.MoneyFormat
import com.aurellia.reports.data.MonthlyCashFlow
import com.aurellia.reports.data.ShortMonth
import com.aurellia.reports.ui.theme.Blush
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.Ink
import com.aurellia.reports.ui.theme.Mauve
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.OutlinePink

@Composable
fun CashFlowChart(
    flows: List<MonthlyCashFlow>,
    modifier: Modifier = Modifier
) {
    if (flows.isEmpty() || flows.all { it.incomeMinor == 0L && it.expenseMinor == 0L }) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(150.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "Add income or expenses to see your cash flow.",
                style = MaterialTheme.typography.bodySmall,
                color = MutedInk,
                textAlign = TextAlign.Center
            )
        }
        return
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
        ) {
            val maxPositive = flows.maxOf {
                maxOf(it.incomeMinor, it.expenseMinor)
                    .coerceAtLeast(it.netMinor)
                    .coerceAtLeast(0L)
            }
            val minNegative = flows.minOf { it.netMinor.coerceAtMost(0L) }
            val span = (maxPositive - minNegative).coerceAtLeast(1L).toFloat()
            val topPad = 10.dp.toPx()
            val bottomPad = 8.dp.toPx()
            val chartHeight = (size.height - topPad - bottomPad).coerceAtLeast(1f)
            val zeroY = topPad + (maxPositive.toFloat() / span) * chartHeight

            fun yFor(value: Long): Float =
                topPad + ((maxPositive - value).toFloat() / span) * chartHeight

            val groupWidth = size.width / flows.size
            val barWidth = (groupWidth * 0.24f).coerceAtLeast(2.dp.toPx())
            val barGap = (groupWidth * 0.06f).coerceAtLeast(1.dp.toPx())

            drawLine(
                color = OutlinePink,
                start = Offset(0f, zeroY),
                end = Offset(size.width, zeroY),
                strokeWidth = 1.dp.toPx()
            )

            fun drawBar(left: Float, value: Long, color: Color) {
                if (value <= 0L) return
                val top = yFor(value)
                val height = (zeroY - top).coerceAtLeast(1f)
                drawRoundRect(
                    color = color,
                    topLeft = Offset(left, top),
                    size = Size(barWidth, height),
                    cornerRadius = CornerRadius(3.dp.toPx())
                )
            }

            flows.forEachIndexed { index, flow ->
                val center = groupWidth * index + groupWidth / 2f
                val pairWidth = barWidth * 2f + barGap
                val left = center - pairWidth / 2f
                drawBar(left, flow.incomeMinor, DeepRose)
                drawBar(left + barWidth + barGap, flow.expenseMinor, Mauve)
            }

            val netPath = Path()
            flows.forEachIndexed { index, flow ->
                val x = groupWidth * index + groupWidth / 2f
                val y = yFor(flow.netMinor)
                if (index == 0) netPath.moveTo(x, y) else netPath.lineTo(x, y)
            }
            drawPath(
                path = netPath,
                color = Ink,
                style = Stroke(
                    width = 2.dp.toPx(),
                    cap = StrokeCap.Round,
                    join = StrokeJoin.Round
                )
            )
            flows.forEachIndexed { index, flow ->
                val x = groupWidth * index + groupWidth / 2f
                drawCircle(
                    color = Ink,
                    radius = 2.5.dp.toPx(),
                    center = Offset(x, yFor(flow.netMinor))
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth()) {
            flows.forEach { flow ->
                Text(
                    text = flow.month.format(ShortMonth),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedInk
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ChartLegend(color = DeepRose, label = "Income")
            ChartLegend(color = Mauve, label = "Expenses")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Box(
                    Modifier
                        .width(14.dp)
                        .height(2.dp)
                        .background(Ink, RoundedCornerShape(50))
                )
                Text(
                    text = "Net",
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedInk
                )
            }
        }
    }
}

@Composable
private fun ChartLegend(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            Modifier
                .size(8.dp)
                .background(color, CircleShape)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedInk
        )
    }
}

@Composable
fun CategoryBreakdown(
    bars: List<Pair<String, Long>>,
    modifier: Modifier = Modifier
) {
    if (bars.isEmpty()) {
        Text(
            text = "No expenses logged in this month.",
            modifier = modifier.fillMaxWidth(),
            style = MaterialTheme.typography.bodySmall,
            color = MutedInk
        )
        return
    }

    val max = bars.maxOf { it.second }.coerceAtLeast(1L)
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        bars.forEach { (category, amount) ->
            val fraction = (amount.toFloat() / max).coerceIn(0.02f, 1f)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = category,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = Ink
                    )
                    Text(
                        text = MoneyFormat.format(amount),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = DeepRose
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Blush, RoundedCornerShape(50))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .height(8.dp)
                            .background(DeepRose, RoundedCornerShape(50))
                    )
                }
            }
        }
    }
}
