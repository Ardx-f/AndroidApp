package com.aurellia.reports.ui.components

import android.app.DatePickerDialog
import android.content.Context
import java.time.LocalDate

fun showDatePicker(
    context: Context,
    initial: LocalDate,
    onPicked: (LocalDate) -> Unit
) {
    val dialog = DatePickerDialog(
        context,
        { _, year, month, day ->
            onPicked(LocalDate.of(year, month + 1, day))
        },
        initial.year,
        initial.monthValue - 1,
        initial.dayOfMonth
    )
    // Period logs are records of days that have happened, so don't allow future dates.
    dialog.datePicker.maxDate = System.currentTimeMillis()
    dialog.show()
}
