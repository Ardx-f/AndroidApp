package com.aurellia.reports.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.PeriodEntry
import com.aurellia.reports.ui.theme.Blush
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.OutlinePink

@Composable
fun EntryCard(
    entry: PeriodEntry,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: (@Composable () -> Unit)? = null
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, OutlinePink)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    val duration = entry.durationDays
                    Text(
                        text = entry.rangeLabel,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$duration ${if (duration == 1) "day" else "days"} • ${entry.flow.label}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                }
                if (entry.end == null) {
                    Pill(text = "Ongoing", container = Blush, content = DeepRose)
                }
                trailing?.invoke()
            }

            val details = buildList {
                entry.mood?.let { add("${it.symbol} ${it.label}") }
                if (entry.symptoms.isNotEmpty()) add(entry.symptoms.sorted().joinToString(" · "))
            }
            if (details.isNotEmpty()) {
                Text(
                    text = details.joinToString("   "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedInk,
                    fontWeight = FontWeight.Normal
                )
            }
            if (entry.notes.isNotBlank()) {
                Text(
                    text = entry.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedInk
                )
            }
        }
    }
}

@Composable
fun Pill(
    text: String,
    container: androidx.compose.ui.graphics.Color,
    content: androidx.compose.ui.graphics.Color
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = container
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium,
            color = content
        )
    }
}
