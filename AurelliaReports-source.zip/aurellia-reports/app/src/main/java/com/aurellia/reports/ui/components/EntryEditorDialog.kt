package com.aurellia.reports.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.Flow
import com.aurellia.reports.data.LongDate
import com.aurellia.reports.data.Mood
import com.aurellia.reports.data.PeriodEntry
import com.aurellia.reports.ui.theme.MutedInk

private val symptomOptions = listOf(
    "Cramps",
    "Headache",
    "Bloating",
    "Fatigue",
    "Backache",
    "Nausea",
    "Tender breasts",
    "Acne",
    "Cravings",
    "Insomnia"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EntryEditorDialog(
    entry: PeriodEntry,
    onDismiss: () -> Unit,
    onSave: (PeriodEntry) -> Unit
) {
    var end by remember(entry.id) { mutableStateOf(entry.end) }
    var flow by remember(entry.id) { mutableStateOf(entry.flow) }
    var mood by remember(entry.id) { mutableStateOf(entry.mood) }
    var symptoms by remember(entry.id) { mutableStateOf(entry.symptoms) }
    var notes by remember(entry.id) { mutableStateOf(entry.notes) }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Period details") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Started ${entry.start.format(LongDate)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )

                val endLabel = end?.let { "Ends ${it.format(LongDate)}" } ?: "Set end date"
                OutlinedButton(
                    onClick = {
                        showDatePicker(context, end ?: entry.start) { picked ->
                            if (!picked.isBefore(entry.start)) end = picked
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(endLabel)
                }
                if (end != null) {
                    TextButton(onClick = { end = null }) {
                        Text("Mark as ongoing")
                    }
                }

                Text("Flow", style = MaterialTheme.typography.labelLarge)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Flow.entries.forEach { option ->
                        FilterChip(
                            selected = flow == option,
                            onClick = { flow = option },
                            label = { Text(option.label) }
                        )
                    }
                }

                Text("Mood", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Mood.entries.forEach { option ->
                        FilterChip(
                            selected = mood == option,
                            onClick = { mood = if (mood == option) null else option },
                            label = { Text("${option.symbol} ${option.label}") }
                        )
                    }
                }

                Text("Symptoms", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    symptomOptions.forEach { symptom ->
                        val selected = symptom in symptoms
                        FilterChip(
                            selected = selected,
                            onClick = {
                                symptoms = if (selected) symptoms - symptom else symptoms + symptom
                            },
                            label = { Text(symptom) }
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Notes") },
                    placeholder = { Text("Anything you want to remember") },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onSave(
                        entry.copy(
                            end = end,
                            flow = flow,
                            mood = mood,
                            symptoms = symptoms,
                            notes = notes
                        )
                    )
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
