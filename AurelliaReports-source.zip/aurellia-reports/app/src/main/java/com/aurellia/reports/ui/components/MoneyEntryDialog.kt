package com.aurellia.reports.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.LongDate
import com.aurellia.reports.data.MoneyCategories
import com.aurellia.reports.data.MoneyEntry
import com.aurellia.reports.data.MoneyFormat
import com.aurellia.reports.data.MoneyType
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.MutedInk

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MoneyEntryDialog(
    entry: MoneyEntry,
    onDismiss: () -> Unit,
    onSave: (MoneyEntry) -> Unit
) {
    val context = LocalContext.current
    val isNew = entry.amountMinor <= 0L
    var type by remember(entry.id) { mutableStateOf(entry.type) }
    var amountText by remember(entry.id) {
        mutableStateOf(if (isNew) "" else MoneyFormat.toInput(entry.amountMinor))
    }
    var date by remember(entry.id) { mutableStateOf(entry.date) }
    var category by remember(entry.id) {
        mutableStateOf(entry.category.ifBlank { MoneyCategories.forType(entry.type).first() })
    }
    var note by remember(entry.id) { mutableStateOf(entry.note) }
    var error by remember(entry.id) { mutableStateOf<String?>(null) }

    val categories = (MoneyCategories.forType(type) + category).distinct()
    val parsed = MoneyFormat.parseToMinor(amountText)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${if (isNew) "New" else "Edit"} ${type.label.lowercase()}") },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 500.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyType.entries.forEach { option ->
                        FilterChip(
                            selected = type == option,
                            onClick = {
                                type = option
                                if (category !in MoneyCategories.forType(option)) {
                                    category = MoneyCategories.forType(option).first()
                                }
                            },
                            label = { Text(option.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = amountText,
                    onValueChange = {
                        amountText = it
                        error = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Amount") },
                    placeholder = { Text("0.00") },
                    singleLine = true,
                    isError = error != null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
                if (error != null) {
                    Text(
                        text = error.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                } else if (parsed != null) {
                    Text(
                        text = "Shows as ${MoneyFormat.format(parsed)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                }

                OutlinedButton(
                    onClick = {
                        showDatePicker(context, date) { picked -> date = picked }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Date: ${date.format(LongDate)}")
                }

                Text("Category", style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { option ->
                        FilterChip(
                            selected = category == option,
                            onClick = { category = option },
                            label = { Text(option) }
                        )
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Note (optional)") },
                    placeholder = { Text("What was this for?") },
                    minLines = 2
                )

                Text(
                    text = "Amounts use your device currency. Everything stays on this device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = DeepRose
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    val amount = MoneyFormat.parseToMinor(amountText)
                    if (amount == null) {
                        error = "Enter an amount greater than zero."
                    } else {
                        onSave(
                            entry.copy(
                                type = type,
                                date = date,
                                amountMinor = amount,
                                category = category,
                                note = note.trim()
                            )
                        )
                    }
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
