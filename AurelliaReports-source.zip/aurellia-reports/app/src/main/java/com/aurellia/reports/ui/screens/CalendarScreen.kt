package com.aurellia.reports.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.LongDate
import com.aurellia.reports.data.MonthYear
import com.aurellia.reports.data.PeriodEntry
import com.aurellia.reports.ui.components.EntryEditorDialog
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.Ink
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.OutlinePink
import com.aurellia.reports.ui.theme.Petal
import com.aurellia.reports.ui.theme.Rose
import java.time.LocalDate
import java.time.YearMonth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(
    today: LocalDate,
    entries: List<PeriodEntry>,
    onStartPeriod: (LocalDate) -> Unit,
    onEndPeriod: (LocalDate) -> Unit,
    onSaveEntry: (PeriodEntry) -> Unit,
    onDeleteEntry: (Long) -> Unit
) {
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var editingEntry by remember { mutableStateOf<PeriodEntry?>(null) }
    var pendingDelete by remember { mutableStateOf<PeriodEntry?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            text = "Calendar",
            style = MaterialTheme.typography.headlineMedium,
            color = Ink
        )
        Text(
            text = "Tap a day to start, end, or edit a period.",
            style = MaterialTheme.typography.bodyMedium,
            color = MutedInk
        )

        CalendarCard(
            month = month,
            entries = entries,
            today = today,
            onPrevious = { month = month.minusMonths(1) },
            onNext = { month = month.plusMonths(1) },
            onSelect = { selectedDate = it }
        )

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Petal)
            )
            Text(
                text = "Period day",
                style = MaterialTheme.typography.bodySmall,
                color = MutedInk
            )
        }

        Spacer(Modifier.height(20.dp))
    }

    selectedDate?.let { date ->
        ModalBottomSheet(
            onDismissRequest = { selectedDate = null },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            DaySheet(
                date = date,
                today = today,
                entries = entries,
                onStart = onStartPeriod,
                onEnd = onEndPeriod,
                onEdit = { editingEntry = it },
                onDelete = { pendingDelete = it },
                onDismiss = { selectedDate = null }
            )
        }
    }

    editingEntry?.let { entry ->
        EntryEditorDialog(
            entry = entry,
            onDismiss = { editingEntry = null },
            onSave = {
                onSaveEntry(it)
                editingEntry = null
            }
        )
    }

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete this period?") },
            text = { Text("This removes the entry for ${entry.rangeLabel}. This can’t be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteEntry(entry.id)
                        pendingDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun CalendarCard(
    month: YearMonth,
    entries: List<PeriodEntry>,
    today: LocalDate,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSelect: (LocalDate) -> Unit
) {
    val weekdays = listOf("M", "T", "W", "T", "F", "S", "S")
    val firstDayOffset = month.atDay(1).dayOfWeek.value - 1
    val dayCount = month.lengthOfMonth()
    val rowCount = (firstDayOffset + dayCount + 6) / 7

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, OutlinePink)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPrevious) {
                    Icon(Icons.Outlined.ChevronLeft, contentDescription = "Previous month")
                }
                Text(
                    text = month.format(MonthYear),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge,
                    color = Ink
                )
                IconButton(onClick = onNext) {
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "Next month")
                }
            }

            Row {
                weekdays.forEach { label ->
                    Text(
                        text = label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = MutedInk
                    )
                }
            }

            for (row in 0 until rowCount) {
                Row {
                    for (column in 0..6) {
                        val dayNumber = row * 7 + column - firstDayOffset + 1
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .padding(2.dp)
                        ) {
                            if (dayNumber in 1..dayCount) {
                                val date = month.atDay(dayNumber)
                                DayCell(
                                    date = date,
                                    inPeriod = entries.any { it.covers(date, today) },
                                    isToday = date == today,
                                    onClick = { onSelect(date) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    date: LocalDate,
    inPeriod: Boolean,
    isToday: Boolean,
    onClick: () -> Unit
) {
    val modifier = Modifier
        .fillMaxSize()
        .clip(CircleShape)
        .background(if (inPeriod) Petal else Color.Transparent)
        .then(
            if (isToday) Modifier.border(BorderStroke(1.5.dp, Rose), CircleShape)
            else Modifier
        )
        .clickable(onClick = onClick)

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Text(
            text = date.dayOfMonth.toString(),
            style = MaterialTheme.typography.bodyMedium,
            color = if (inPeriod) DeepRose else Ink,
            fontWeight = if (inPeriod || isToday) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun DaySheet(
    date: LocalDate,
    today: LocalDate,
    entries: List<PeriodEntry>,
    onStart: (LocalDate) -> Unit,
    onEnd: (LocalDate) -> Unit,
    onEdit: (PeriodEntry) -> Unit,
    onDelete: (PeriodEntry) -> Unit,
    onDismiss: () -> Unit
) {
    val entry = entries.firstOrNull { it.covers(date, today) }
    val active = entries
        .filter { it.end == null && !date.isBefore(it.start) }
        .maxByOrNull { it.start.toEpochDay() }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = date.format(LongDate),
            style = MaterialTheme.typography.headlineSmall,
            color = Ink
        )

        when {
            date.isAfter(today) -> {
                Text(
                    text = "Future date. Log this day after it begins; Today shows the prediction.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
            }

            entry != null -> {
                Text(
                    text = "Part of ${entry.rangeLabel}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
                Button(
                    onClick = {
                        onEdit(entry)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Edit period details")
                }
                if (entry.end == null) {
                    OutlinedButton(
                        onClick = {
                            onEnd(date)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("End period on this day")
                    }
                }
                TextButton(
                    onClick = {
                        onDelete(entry)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Delete this period",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            active != null && date.isAfter(active.start) -> {
                Text(
                    text = "Ongoing period started ${active.start.format(LongDate)}.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
                Button(
                    onClick = {
                        onEnd(date)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("End period on this day")
                }
            }

            else -> {
                Text(
                    text = "No period logged for this day.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
                Button(
                    onClick = {
                        onStart(date)
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Start period on this day")
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}
