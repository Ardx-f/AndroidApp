package com.aurellia.reports.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.CycleStatus
import com.aurellia.reports.data.PeriodEntry
import com.aurellia.reports.data.ShortDate
import com.aurellia.reports.ui.components.EmptyStateCard
import com.aurellia.reports.ui.components.EntryCard
import com.aurellia.reports.ui.components.EntryEditorDialog
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.Rose

@Composable
fun HistoryScreen(
    entries: List<PeriodEntry>,
    status: CycleStatus,
    onSaveEntry: (PeriodEntry) -> Unit,
    onDeleteEntry: (Long) -> Unit
) {
    val sorted = remember(entries) { entries.sortedByDescending { it.start.toEpochDay() } }
    var editingEntry by remember { mutableStateOf<PeriodEntry?>(null) }
    var pendingDelete by remember { mutableStateOf<PeriodEntry?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "History",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Your logged cycles, newest first.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${status.averageCycle} days",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Average cycle",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedInk
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${entries.size}",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Periods logged",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedInk
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = status.lastEntry?.start?.format(ShortDate) ?: "—",
                            style = MaterialTheme.typography.titleLarge
                        )
                        Text(
                            text = "Last start",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedInk
                        )
                    }
                }
            }
        }

        if (sorted.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "Your history is empty",
                    body = "Logged periods will appear here with their flow, symptoms, and notes."
                )
            }
        } else {
            items(sorted, key = { it.id }) { entry ->
                EntryCard(
                    entry = entry,
                    onClick = { editingEntry = entry },
                    trailing = {
                        IconButton(onClick = { pendingDelete = entry }) {
                            Icon(
                                imageVector = Icons.Outlined.DeleteOutline,
                                contentDescription = "Delete period",
                                tint = Rose,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                )
            }
        }

        item {
            Text(
                text = "Aurellia Reports is a personal record, not medical advice.",
                style = MaterialTheme.typography.bodySmall,
                color = MutedInk,
                modifier = Modifier.padding(top = 6.dp)
            )
            Spacer(Modifier.height(10.dp))
        }
    }

    editingEntry?.let { entry ->
        EntryEditorDialog(
            entry = entry,
            onDismiss = { editingEntry = null },
            onSave = {
                onSaveEntry(it)
                editingEntry = null
            }
        )
    }

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete this period?") },
            text = {
                Text("This removes the entry for ${entry.rangeLabel}. This can’t be undone.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteEntry(entry.id)
                        pendingDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
