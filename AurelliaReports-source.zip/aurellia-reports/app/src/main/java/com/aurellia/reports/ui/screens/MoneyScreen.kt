package com.aurellia.reports.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.TrendingDown
import androidx.compose.material.icons.automirrored.outlined.TrendingUp
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.LongDate
import com.aurellia.reports.data.MoneyCalculator
import com.aurellia.reports.data.MoneyCategories
import com.aurellia.reports.data.MoneyEntry
import com.aurellia.reports.data.MoneyFormat
import com.aurellia.reports.data.MoneySummary
import com.aurellia.reports.data.MoneyType
import com.aurellia.reports.data.MonthYear
import com.aurellia.reports.ui.components.CashFlowChart
import com.aurellia.reports.ui.components.CategoryBreakdown
import com.aurellia.reports.ui.components.MoneyEntryDialog
import com.aurellia.reports.ui.theme.Blush
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.Ink
import com.aurellia.reports.ui.theme.Mauve
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.OutlinePink
import com.aurellia.reports.ui.theme.Petal
import com.aurellia.reports.ui.theme.Rose
import com.aurellia.reports.ui.theme.SoftPink
import java.time.LocalDate
import java.time.YearMonth

@Composable
fun MoneyScreen(
    entries: List<MoneyEntry>,
    today: LocalDate,
    onSave: (MoneyEntry) -> Unit,
    onDelete: (Long) -> Unit
) {
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var editingEntry by remember { mutableStateOf<MoneyEntry?>(null) }
    var pendingDelete by remember { mutableStateOf<MoneyEntry?>(null) }

    val currentMonth = YearMonth.from(today)
    val canGoForward = month < currentMonth
    val summary = remember(entries, month) { MoneyCalculator.summary(entries, month) }
    val monthly = remember(entries, month) { MoneyCalculator.monthly(entries, month) }
    val monthEntries = remember(entries, month) {
        MoneyCalculator.entriesForMonth(entries, month)
    }
    val categories = remember(entries, month) {
        MoneyCalculator.expensesByCategory(entries, month)
    }

    fun newEntry(type: MoneyType): MoneyEntry = MoneyEntry(
        id = System.currentTimeMillis(),
        date = defaultDateForMonth(month, today),
        type = type,
        amountMinor = 0L,
        category = MoneyCategories.forType(type).first()
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Money",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Ink
                )
                Text(
                    text = "Income, spending, and cash flow — all stored on this device.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
            }
        }

        item {
            MonthSwitcher(
                month = month,
                canGoForward = canGoForward,
                onPrevious = { month = month.minusMonths(1) },
                onNext = { if (canGoForward) month = month.plusMonths(1) }
            )
        }

        item {
            MoneyHero(month = month, summary = summary)
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { editingEntry = newEntry(MoneyType.INCOME) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeepRose,
                        contentColor = Color.White
                    )
                ) {
                    Text("+ Income")
                }
                OutlinedButton(
                    onClick = { editingEntry = newEntry(MoneyType.EXPENSE) },
                    modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, OutlinePink)
                ) {
                    Text("− Expense")
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlinePink)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Cash flow",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.titleLarge,
                            color = Ink
                        )
                        Text(
                            text = "Last 6 months",
                            style = MaterialTheme.typography.labelSmall,
                            color = MutedInk
                        )
                    }
                    CashFlowChart(flows = monthly)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, OutlinePink)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Where the money went",
                        style = MaterialTheme.typography.titleLarge,
                        color = Ink
                    )
                    Text(
                        text = "Expenses in ${month.format(MonthYear)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                    CategoryBreakdown(bars = categories)
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Records",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.titleLarge,
                    color = Ink
                )
                Text(
                    text = "${monthEntries.size}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MutedInk
                )
            }
        }

        if (monthEntries.isEmpty()) {
            item {
                MoneyEmptyState()
            }
        } else {
            items(monthEntries, key = { it.id }) { entry ->
                MoneyEntryRow(
                    entry = entry,
                    onClick = { editingEntry = entry },
                    onDelete = { pendingDelete = entry }
                )
            }
        }
    }

    editingEntry?.let { entry ->
        MoneyEntryDialog(
            entry = entry,
            onDismiss = { editingEntry = null },
            onSave = {
                onSave(it)
                editingEntry = null
            }
        )
    }

    pendingDelete?.let { entry ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete this record?") },
            text = {
                Text(
                    "This removes ${MoneyFormat.signed(entry)} for ${entry.category} on " +
                        "${entry.date.format(LongDate)}. This can’t be undone."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete(entry.id)
                        pendingDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MonthSwitcher(
    month: YearMonth,
    canGoForward: Boolean,
    onPrevious: () -> Unit,
    onNext: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onPrevious) {
            Icon(Icons.Outlined.ChevronLeft, contentDescription = "Previous month")
        }
        Text(
            text = month.format(MonthYear),
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.titleLarge,
            color = Ink
        )
        IconButton(onClick = onNext, enabled = canGoForward) {
            Icon(Icons.Outlined.ChevronRight, contentDescription = "Next month")
        }
    }
}

@Composable
private fun MoneyHero(
    month: YearMonth,
    summary: MoneySummary
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(SoftPink, Blush)))
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = month.format(MonthYear).uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = DeepRose
                )
                Text(
                    text = MoneyFormat.format(summary.netMinor),
                    style = MaterialTheme.typography.headlineMedium,
                    color = DeepRose
                )
                Text(
                    text = if (summary.netMinor >= 0) "Net balance" else "Net balance — spending more than income",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedInk
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MoneyStat(
                        label = "Income",
                        value = MoneyFormat.format(summary.incomeMinor),
                        color = DeepRose,
                        modifier = Modifier.weight(1f)
                    )
                    MoneyStat(
                        label = "Expenses",
                        value = MoneyFormat.format(summary.expenseMinor),
                        color = Mauve,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun MoneyStat(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color.White.copy(alpha = 0.65f), RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedInk
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = color
        )
    }
}

@Composable
private fun MoneyEntryRow(
    entry: MoneyEntry,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val isIncome = entry.type == MoneyType.INCOME
    val accent = if (isIncome) DeepRose else Mauve
    val icon = if (isIncome) Icons.AutoMirrored.Outlined.TrendingUp else Icons.AutoMirrored.Outlined.TrendingDown

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, OutlinePink)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(if (isIncome) Petal else Blush, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = entry.category,
                    style = MaterialTheme.typography.titleMedium,
                    color = Ink
                )
                Text(
                    text = entry.date.format(LongDate),
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedInk
                )
                if (entry.note.isNotBlank()) {
                    Text(
                        text = entry.note,
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = MoneyFormat.signed(entry),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = accent
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = "Delete record",
                        tint = Rose,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MoneyEmptyState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 28.dp, horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Outlined.AccountBalanceWallet,
            contentDescription = null,
            tint = Rose,
            modifier = Modifier.size(34.dp)
        )
        Text(
            text = "No records for this month",
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Add income or an expense to start your cash flow history.",
            style = MaterialTheme.typography.bodySmall,
            color = MutedInk,
            textAlign = TextAlign.Center
        )
    }
}

private fun defaultDateForMonth(month: YearMonth, today: LocalDate): LocalDate {
    val current = YearMonth.from(today)
    return when {
        month == current -> today
        month.isBefore(current) -> month.atEndOfMonth()
        else -> today
    }
}
