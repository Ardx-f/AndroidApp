package com.aurellia.reports.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.AppSettings
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.Rose
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    settings: AppSettings,
    onSettingsChange: (AppSettings) -> Unit,
    onReset: () -> Unit
) {
    var showReset by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.headlineMedium
                )
                Text(
                    text = "Tune predictions to match your body.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Cycle length",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${settings.cycleLength} days",
                        style = MaterialTheme.typography.bodySmall,
                        color = DeepRose
                    )
                    Slider(
                        value = settings.cycleLength.toFloat(),
                        onValueChange = {
                            onSettingsChange(settings.copy(cycleLength = it.roundToInt()))
                        },
                        valueRange = 21f..40f,
                        steps = 18
                    )
                    Text(
                        text = "Used when there aren’t enough logged cycles for an average.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )

                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = "Period length",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${settings.periodLength} days",
                        style = MaterialTheme.typography.bodySmall,
                        color = DeepRose
                    )
                    Slider(
                        value = settings.periodLength.toFloat(),
                        onValueChange = {
                            onSettingsChange(settings.copy(periodLength = it.roundToInt()))
                        },
                        valueRange = 2f..10f,
                        steps = 7
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = null,
                            tint = Rose,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Privacy by design",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Text(
                        text = "Aurellia Reports has no internet permission. Your cycle and money data is stored only in this app’s private storage and is not sent anywhere.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                    Text(
                        text = "Uninstalling the app removes the data. Export or back up first if you want to keep it.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "About",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Aurellia Reports 1.0.0",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                    Text(
                        text = "A calm, local-only cycle and cash-flow journal. Not medical or financial advice. If something feels unusual, talk to a qualified professional.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MutedInk
                    )
                    Spacer(Modifier.height(4.dp))
                    TextButton(
                        onClick = { showReset = true },
                        modifier = Modifier.padding(0.dp)
                    ) {
                        Text("Reset all data", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("Reset all data?") },
            text = { Text("This removes every period, symptom, note, money record, and setting. This can’t be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onReset()
                        showReset = false
                    }
                ) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
