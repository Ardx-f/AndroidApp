package com.aurellia.reports.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurellia.reports.data.AppSettings
import com.aurellia.reports.data.CycleStatus
import com.aurellia.reports.data.FullDayDate
import com.aurellia.reports.data.PeriodEntry
import com.aurellia.reports.data.ShortDate
import com.aurellia.reports.ui.components.EmptyStateCard
import com.aurellia.reports.ui.components.EntryCard
import com.aurellia.reports.ui.components.EntryEditorDialog
import com.aurellia.reports.ui.components.Pill
import com.aurellia.reports.ui.components.SectionHeader
import com.aurellia.reports.ui.components.StatCard
import com.aurellia.reports.ui.components.showDatePicker
import com.aurellia.reports.ui.theme.Blush
import com.aurellia.reports.ui.theme.DeepRose
import com.aurellia.reports.ui.theme.Ink
import com.aurellia.reports.ui.theme.Mauve
import com.aurellia.reports.ui.theme.MutedInk
import com.aurellia.reports.ui.theme.OutlinePink
import com.aurellia.reports.ui.theme.Rose
import com.aurellia.reports.ui.theme.SoftPink
import java.time.LocalDate

@Composable
fun TodayScreen(
    today: LocalDate,
    entries: List<PeriodEntry>,
    settings: AppSettings,
    status: CycleStatus,
    onStartPeriod: (LocalDate) -> Unit,
    onEndPeriod: (LocalDate) -> Unit,
    onSaveEntry: (PeriodEntry) -> Unit,
    onOpenHistory: () -> Unit
) {
    val context = LocalContext.current
    var editingEntry by remember { mutableStateOf<PeriodEntry?>(null) }
    val recent = remember(entries) { entries.sortedByDescending { it.start.toEpochDay() }.take(3) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 30.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "AURELLIA REPORTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = DeepRose
                )
                Text(
                    text = today.format(FullDayDate),
                    style = MaterialTheme.typography.headlineMedium,
                    color = Ink
                )
                Text(
                    text = "A gentle record of your cycle.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedInk
                )
            }
        }

        item {
            CycleHero(status = status)
        }

        item {
            QuickActions(
                hasActive = status.activeEntry != null,
                hasAny = status.lastEntry != null,
                onStartToday = { onStartPeriod(today) },
                onEndToday = { onEndPeriod(today) },
                onEditDetails = {
                    editingEntry = status.activeEntry
                        ?: status.lastEntry
                        ?: PeriodEntry(id = System.currentTimeMillis(), start = today)
                },
                onPickDate = {
                    showDatePicker(context, today) { picked -> onStartPeriod(picked) }
                }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    label = "Avg cycle",
                    value = "${status.averageCycle} days",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "Period",
                    value = "${settings.periodLength} days",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "Logged",
                    value = "${entries.size}",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            SectionHeader(
                title = "Recent periods",
                actionLabel = if (recent.isNotEmpty()) "View all" else null,
                onAction = onOpenHistory
            )
        }

        if (recent.isEmpty()) {
            item {
                EmptyStateCard(
                    title = "No periods logged yet",
                    body = "Tap “Start period” to begin. Everything you record stays on this device."
                )
            }
        } else {
            items(recent, key = { it.id }) { entry ->
                EntryCard(entry = entry, onClick = { editingEntry = entry })
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Lock,
                    contentDescription = null,
                    tint = Rose,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Private by design. Nothing leaves your phone.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MutedInk
                )
            }
        }
    }

    editingEntry?.let { entry ->
        EntryEditorDialog(
            entry = entry,
            onDismiss = { editingEntry = null },
            onSave = {
                onSaveEntry(it)
                editingEntry = null
            }
        )
    }
}

@Composable
private fun QuickActions(
    hasActive: Boolean,
    hasAny: Boolean,
    onStartToday: () -> Unit,
    onEndToday: () -> Unit,
    onEditDetails: () -> Unit,
    onPickDate: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = if (hasActive) onEndToday else onStartToday,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeepRose,
                    contentColor = Color.White
                )
            ) {
                if (!hasActive) {
                    Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                }
                Text(if (hasActive) "End period" else "Start period")
            }
            OutlinedButton(
                onClick = onEditDetails,
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, OutlinePink)
            ) {
                Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (hasAny) "Log details" else "Log today")
            }
        }
        TextButton(
            onClick = onPickDate,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Or start a period on another date", color = DeepRose)
        }
    }
}

@Composable
private fun CycleHero(status: CycleStatus) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(SoftPink, Blush)))
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CycleRing(status = status)
                Spacer(Modifier.width(18.dp))
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Pill(
                        text = status.phase.label,
                        container = Color.White.copy(alpha = 0.7f),
                        content = DeepRose
                    )
                    val next = status.nextPeriod
                    if (next != null) {
                        val days = status.daysUntilNext
                        Text(
                            text = when {
                                days == null -> "Next period"
                                days >= 0 -> "Next period in $days ${if (days == 1L) "day" else "days"}"
                                else -> "Period is ${-days} ${if (-days == 1L) "day" else "days"} late"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = Ink
                        )
                        Text(
                            text = "Expected ${next.format(ShortDate)}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MutedInk
                        )
                    } else {
                        Text(
                            text = "Log your first period to start tracking.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Ink
                        )
                    }
                    if (status.isLate) {
                        Text(
                            text = "Predictions can shift. Log a new start date when it begins.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DeepRose
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CycleRing(status: CycleStatus) {
    val progress = status.cycleDay
        ?.let { (it.toFloat() / status.averageCycle.coerceAtLeast(1)).coerceIn(0f, 1f) }
        ?: 0f

    Box(
        modifier = Modifier.size(128.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 11.dp.toPx()
            drawArc(
                color = Color.White.copy(alpha = 0.75f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            if (progress > 0f) {
                drawArc(
                    color = Rose,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = status.cycleDay?.let { "Day $it" } ?: "—",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                color = DeepRose
            )
            Text(
                text = if (status.cycleDay != null) "of ~${status.averageCycle}" else "no cycle yet",
                style = MaterialTheme.typography.labelSmall,
                color = Mauve
            )
        }
    }
}
