package com.aurellia.reports.ui.theme

import androidx.compose.ui.graphics.Color

// Pastel rose + white palette
val Rose = Color(0xFFD96C8C)
val DeepRose = Color(0xFF8E2A4B)
val Blush = Color(0xFFFCE4EC)
val Petal = Color(0xFFF8BBD0)
val SoftPink = Color(0xFFFFF0F5)
val Cream = Color(0xFFFFFBFD)
val Mauve = Color(0xFF7A4A5A)
val OutlinePink = Color(0xFFF2C6D4)
val Ink = Color(0xFF3B2530)
val MutedInk = Color(0xFF6E5560)
