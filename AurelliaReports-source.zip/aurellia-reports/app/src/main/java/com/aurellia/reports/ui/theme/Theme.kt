package com.aurellia.reports.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val SecondaryRose = Color(0xFFB5657E)
private val TertiaryRose = Color(0xFFC98BA0)

private val AurelliaColors = lightColorScheme(
    primary = DeepRose,
    onPrimary = Color.White,
    primaryContainer = Blush,
    onPrimaryContainer = DeepRose,
    secondary = SecondaryRose,
    onSecondary = Cream,
    secondaryContainer = SoftPink,
    onSecondaryContainer = Mauve,
    tertiary = TertiaryRose,
    onTertiary = Cream,
    background = Cream,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = SoftPink,
    onSurfaceVariant = MutedInk,
    outline = OutlinePink,
    outlineVariant = Blush,
    error = Color(0xFFBA1A1A),
    onError = Color.White
)

private val AurelliaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(34.dp)
)

@Composable
fun AurelliaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AurelliaColors,
        typography = AurelliaTypography,
        shapes = AurelliaShapes,
        content = content
    )
}
