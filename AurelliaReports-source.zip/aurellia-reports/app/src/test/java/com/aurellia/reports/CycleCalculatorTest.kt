package com.aurellia.reports

import com.aurellia.reports.data.AppSettings
import com.aurellia.reports.data.CycleCalculator
import com.aurellia.reports.data.CyclePhase
import com.aurellia.reports.data.PeriodEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class CycleCalculatorTest {

    @Test
    fun noHistoryUsesFallbackSettings() {
        val status = CycleCalculator.calculate(
            entries = emptyList(),
            settings = AppSettings(cycleLength = 30, periodLength = 4),
            today = LocalDate.of(2026, 1, 1)
        )

        assertEquals(30, status.averageCycle)
        assertNull(status.cycleDay)
        assertNull(status.nextPeriod)
        assertEquals(CyclePhase.NONE, status.phase)
        assertFalse(status.isLate)
    }

    @Test
    fun predictsNextPeriodFromLastStart() {
        val entry = PeriodEntry(
            id = 1L,
            start = LocalDate.of(2026, 1, 1),
            end = LocalDate.of(2026, 1, 5)
        )

        val status = CycleCalculator.calculate(
            entries = listOf(entry),
            settings = AppSettings(cycleLength = 28, periodLength = 5),
            today = LocalDate.of(2026, 1, 10)
        )

        assertEquals(10, status.cycleDay)
        assertEquals(LocalDate.of(2026, 1, 29), status.nextPeriod)
        assertEquals(19L, status.daysUntilNext)
        assertEquals(CyclePhase.FOLLICULAR, status.phase)
        assertFalse(status.isLate)
    }

    @Test
    fun activePeriodIsMarkedMenstrual() {
        val entry = PeriodEntry(
            id = 2L,
            start = LocalDate.of(2026, 1, 8),
            end = null
        )

        val status = CycleCalculator.calculate(
            entries = listOf(entry),
            settings = AppSettings(cycleLength = 28, periodLength = 5),
            today = LocalDate.of(2026, 1, 10)
        )

        assertEquals(3, status.cycleDay)
        assertEquals(CyclePhase.MENSTRUAL, status.phase)
        assertTrue(status.activeEntry != null)
        assertFalse(status.isLate)
    }
}
