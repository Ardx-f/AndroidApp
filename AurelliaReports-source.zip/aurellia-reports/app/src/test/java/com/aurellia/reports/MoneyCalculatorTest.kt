package com.aurellia.reports

import com.aurellia.reports.data.MoneyCalculator
import com.aurellia.reports.data.MoneyEntry
import com.aurellia.reports.data.MoneyFormat
import com.aurellia.reports.data.MoneyType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class MoneyCalculatorTest {

    private fun entry(
        id: Long,
        month: Int,
        day: Int = 10,
        type: MoneyType,
        amountMinor: Long,
        category: String
    ) = MoneyEntry(
        id = id,
        date = LocalDate.of(2026, month, day),
        type = type,
        amountMinor = amountMinor,
        category = category
    )

    @Test
    fun summaryOnlyIncludesSelectedMonth() {
        val entries = listOf(
            entry(1, 1, type = MoneyType.INCOME, amountMinor = 500_000, category = "Salary"),
            entry(2, 1, type = MoneyType.EXPENSE, amountMinor = 125_000, category = "Rent"),
            entry(3, 2, type = MoneyType.EXPENSE, amountMinor = 30_000, category = "Food")
        )

        val summary = MoneyCalculator.summary(entries, YearMonth.of(2026, 1))

        assertEquals(500_000L, summary.incomeMinor)
        assertEquals(125_000L, summary.expenseMinor)
        assertEquals(375_000L, summary.netMinor)
    }

    @Test
    fun monthlyCashFlowIsOldestFirstAndEndsAtSelectedMonth() {
        val entries = listOf(
            entry(1, 1, type = MoneyType.INCOME, amountMinor = 100_000, category = "Salary"),
            entry(2, 2, type = MoneyType.EXPENSE, amountMinor = 50_000, category = "Food")
        )

        val flows = MoneyCalculator.monthly(
            entries = entries,
            endMonth = YearMonth.of(2026, 2),
            count = 6
        )

        assertEquals(6, flows.size)
        assertEquals(YearMonth.of(2025, 9), flows.first().month)
        assertEquals(YearMonth.of(2026, 2), flows.last().month)
        assertEquals(100_000L, flows[4].incomeMinor)
        assertEquals(50_000L, flows[5].expenseMinor)
        assertEquals(-50_000L, flows[5].netMinor)
    }

    @Test
    fun expensesAreGroupedAndSortedByCategory() {
        val entries = listOf(
            entry(1, 3, type = MoneyType.EXPENSE, amountMinor = 50_000, category = "Food"),
            entry(2, 3, type = MoneyType.EXPENSE, amountMinor = 25_000, category = "Food"),
            entry(3, 3, type = MoneyType.EXPENSE, amountMinor = 100_000, category = "Rent"),
            entry(4, 3, type = MoneyType.INCOME, amountMinor = 500_000, category = "Salary")
        )

        val categories = MoneyCalculator.expensesByCategory(entries, YearMonth.of(2026, 3))

        assertEquals(
            listOf("Rent" to 100_000L, "Food" to 75_000L),
            categories
        )
    }

    @Test
    fun amountParsingAndInputFormatting() {
        assertEquals(125_050L, MoneyFormat.parseToMinor("1,250.50"))
        assertEquals(1_250L, MoneyFormat.parseToMinor("12,50"))
        assertEquals(125_050L, MoneyFormat.parseToMinor("1.250,50"))
        assertEquals(1_235L, MoneyFormat.parseToMinor("12.345"))
        assertNull(MoneyFormat.parseToMinor("0"))
        assertNull(MoneyFormat.parseToMinor("0.004"))
        assertNull(MoneyFormat.parseToMinor("not a number"))
        assertEquals("1234.56", MoneyFormat.toInput(123_456L))
        assertEquals("1", MoneyFormat.toInput(100L))
    }
}
