# Adding features to Aurellia Reports

This guide is for the standalone `aurellia-reports` project. It intentionally has no permissions and no network code. Keep that boundary unless you deliberately decide otherwise.

> Do not use this guide to merge the tracker into the BABARPHANTOM APK or any app that retains covert collection/remote-control features.

## 1. Add a field to a period entry

Example: add a basal body temperature.

1. Open `data/Models.kt` and add the field:

```kotlin
data class PeriodEntry(
    // ... existing fields ...
    val temperature: Double? = null
)
```

2. Open `data/AurelliaStore.kt`:

- in `entryToJson`, add:

```kotlin
entry.temperature?.let { put("temperature", it) }
```

- in `jsonToEntry`, read it back:

```kotlin
temperature = if (json.has("temperature")) json.optDouble("temperature") else null
```

and pass it to the `PeriodEntry(...)` constructor.

3. Open `ui/components/EntryEditorDialog.kt` and add an input:

```kotlin
var temperature by remember(entry.id) {
    mutableStateOf(entry.temperature?.toString().orEmpty())
}

OutlinedTextField(
    value = temperature,
    onValueChange = { temperature = it },
    label = { Text("Temperature (°C)") },
    modifier = Modifier.fillMaxWidth()
)
```

Include it in `entry.copy(...)`:

```kotlin
temperature = temperature.toDoubleOrNull()
```

4. Show it wherever it matters, for example in `EntryCard`:

```kotlin
entry.temperature?.let {
    Text("${it}°C", style = MaterialTheme.typography.bodySmall)
}
```

Because the store reads and writes JSON, saved entries keep the new field. Older entries simply have no value.

## 2. Add a field to a money record

Money amounts are stored in **minor units** (cents/paise) as `Long`, so totals never accumulate floating-point errors. If you add a field, keep that convention for anything monetary.

1. In `data/MoneyModels.kt`, add the field:

```kotlin
data class MoneyEntry(
    // ... existing fields ...
    val account: String = "Cash"
)
```

2. In `data/AurelliaStore.kt`, write and read it:

```kotlin
private fun moneyToJson(entry: MoneyEntry): JSONObject = JSONObject().apply {
    // ... existing fields ...
    put("account", entry.account)
}
```

```kotlin
MoneyEntry(
    // ... existing arguments ...
    account = json.optString("account").ifBlank { "Cash" }
)
```

3. In `ui/components/MoneyEntryDialog.kt`, add an input and include it in `entry.copy(...)`:

```kotlin
var account by remember(entry.id) { mutableStateOf(entry.account) }

OutlinedTextField(
    value = account,
    onValueChange = { account = it },
    label = { Text("Account") },
    modifier = Modifier.fillMaxWidth()
)
```

4. Show it in `ui/screens/MoneyScreen.kt` (`MoneyEntryRow`) if it is useful.

The JSON store is forgiving: old records without `account` fall back to `"Cash"`. To add a currency setting, keep amounts in minor units and store the currency code separately; never mix currencies in one running total.

## 3. Add a new screen and bottom tab

1. Create `ui/screens/InsightsScreen.kt`:

```kotlin
@Composable
fun InsightsScreen(entries: List<PeriodEntry>) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Insights", style = MaterialTheme.typography.headlineMedium)
        // ...
    }
}
```

2. Open `ui/AurelliaApp.kt`:

- add the import,
- add a tab:

```kotlin
AurelliaTab("Insights", Icons.Outlined.Insights)
```

- and add a branch:

```kotlin
3 -> InsightsScreen(entries = entries)
```

The current branches are `0` Today, `1` Calendar, `2` History, `3` Money, and `4` Settings. Five destinations is already the comfortable limit for a bottom bar, so either replace one while prototyping, or turn Settings into a **More** screen that links to Settings and the new screen. The bottom navigation is just a `when (selectedTab)`, so no navigation library is needed.

## 4. Add local reminders (notifications)

This is the main reason you would add a permission. Keep it local; no server is needed.

1. In `AndroidManifest.xml`, add:

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

2. Create a notification channel in `MainActivity.onCreate` (or an `Application` class).
3. Ask for `POST_NOTIFICATIONS` at runtime on Android 13+ using `ActivityResultContracts.RequestPermission`.
4. Add WorkManager:

```kotlin
implementation("androidx.work:work-runtime-ktx:2.10.0")
```

5. Create a `Worker` that checks `CycleCalculator.calculate(...)` and posts a notification when the predicted start date is near.
6. Schedule a periodic work request from the Settings screen when the user enables reminders.

Use `AlarmManager` only if you need an exact time; prefer WorkManager for a daily check. Never add `INTERNET` just for a reminder.

## 5. Export and import data

Use the Storage Access Framework so the app needs **no storage permission**.

1. Add an "Export" button in Settings.
2. Launch `ActivityResultContracts.CreateDocument("application/json")`.
3. Write the entries as JSON to the returned `Uri` using `contentResolver.openOutputStream(uri)`.
4. For import, launch `ActivityResultContracts.OpenDocument` with `arrayOf("application/json")`, read the stream, parse the JSON, and save through `AurelliaStore`.

You can reuse the private `entryToJson` / `jsonToEntry` functions by making them internal, or expose:

```kotlin
fun exportJson(): String
fun importJson(raw: String)
```

inside `AurelliaStore`. Do not add broad `READ/WRITE_EXTERNAL_STORAGE` permissions.

## 6. Change the prediction logic

`data/CycleCalculator.kt` is pure Kotlin and has no Android dependencies. That makes it easy to test and change.

- `averageCycle` uses the last six gaps between 15 and 60 days.
- `calculate` derives cycle day, phase, next period, late status, and the active entry.

To add a different phase model, edit the `when` block. To add a new statistic, add a field to `CycleStatus` and use it in `TodayScreen` or `HistoryScreen`.

Add tests under `app/src/test/java/com/aurellia/reports/`:

```kotlin
class CycleCalculatorTest {
    @Test
    fun usesFallbackWhenThereIsNoHistory() {
        val status = CycleCalculator.calculate(
            entries = emptyList(),
            settings = AppSettings(cycleLength = 30),
            today = LocalDate.of(2026, 1, 1)
        )
        assertEquals(30, status.averageCycle)
        assertNull(status.cycleDay)
    }
}
```

Add the test dependency if needed:

```kotlin
testImplementation("junit:junit:4.13.2")
```

## 7. Change the palette or typography

- Colors: `ui/theme/Color.kt`
- Material color roles: `ui/theme/Theme.kt`
- Type scale: `ui/theme/Type.kt`

Keep the light scheme if you want the pastel pink/white look. If you add a dark scheme, update `AurelliaColors` and make sure text contrast still passes.

## 8. Release signing

Debug builds are signed automatically. For a release APK/AAB:

1. Create a keystore:

```bash
keytool -genkeypair -v -keystore aurellia-release.jks \
  -alias aurellia -keyalg RSA -keysize 2048 -validity 10000
```

2. Add signing config through environment variables or a local `keystore.properties` file that is **not** committed.
3. Build:

```bash
./gradlew bundleRelease
# or
./gradlew assembleRelease
```

Never commit the keystore or its passwords.

## 9. Keep the privacy promise

If you add a feature that needs a new permission, ask:

- Does this feature need it at all?
- Can it be done with a system picker (SAF, photo picker) instead?
- Is the data staying on-device?
- Is the user clearly informed?

If you ever add cloud sync, use an encrypted transport, explain it in the UI, and let the user opt in. Do not silently collect data, and do not add covert background camera, microphone, SMS, contact, or location collection. The same rule applies to money records: they are personal data too.
